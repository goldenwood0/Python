import platform
import psutil

# OS Name and Version
os_name = platform.system()
os_version = platform.version()

# Processor Information
processor_info = platform.processor()

# Memory (GB)
memory_gb = round(psutil.virtual_memory().total / (1024 ** 3), 2)

# Available Disk Space (GB)
disk_space_gb = round(psutil.disk_usage('/').free / (1024 ** 3), 2)

# Current User
current_user = platform.node()

print(f"OS Name: {os_name} {os_version}")
print(f"Processor Information: {processor_info}")
print(f"Memory (GB): {memory_gb}GB")
print(f"Available Disk Space (GB): {disk_space_gb}GB")
print(f"Current User: {current_user}")
